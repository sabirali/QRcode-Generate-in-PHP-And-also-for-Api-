<?php 
// Example link
//https://github.com/serpro/Android-PHP-Encrypt-Decrypt/blob/master/PHP/MCrypt.php

// http://goqr.me/api/ get api URL.


    function index_post() {
        $iv = 'AEA55FD81837A81F';   //16 character
        $key = '6411BEA71A5EC931';  //16 character
//        require APPPATH . 'third_party/phpqrcode/qrlib.php';
        $user_id = $this->post("user_id");

        // user append and generate key comment by sabirali start
        // $iv_u = $user_id . $iv;
        // $iv_final = substr($iv_u, 0, 16);
        // $key_u = $user_id . $key;
        // $key_final = substr($key_u, 0, 16);
        // END 
        $data_arr = array('user_id' => $user_id,
        );
        $data_json = json_encode($data_arr);
        //$qr_data_enc = $this->encrypt($iv_final, $key_final, $data_json);
        //echo $qr_data_dec = $this->decrypt($iv_final, $key_final, $qr_data_enc);die;
        $qr_data_enc = $this->encrypt($iv, $key, $data_json);
        //echo $qr_data_dec = $this->decrypt($iv, $key, $qr_data_enc);die;
        //QRcode::png($qr_data_enc);
        // http://goqr.me/api/                           get below api.
        $wallet_amount = $this->Qrcode_transaction_history_model->getuser_details($user_id);
        $response['result']['qr_code'] = "https://api.qrserver.com/v1/create-qr-code/?data=$qr_data_enc&size=300x300";
        $response['result']['wallet_t_n_c'] = $wallet_amount->wallet_t_n_c;
        $response['responseMessage'] = "Success";
        $response['responseCode'] = "200";
        // }

        $this->response($response, 201);
    }

    function encrypt($iv_final, $key_final, $str, $isBinary = false) {
        $iv = $iv_final;
        $str = $isBinary ? $str : utf8_decode($str);

        $td = @mcrypt_module_open('rijndael-128', ' ', 'cbc', $iv);

        @mcrypt_generic_init($td, $key_final, $iv);
        $encrypted = @mcrypt_generic($td, $str);

        @mcrypt_generic_deinit($td);
        @mcrypt_module_close($td);

        return $isBinary ? $encrypted : bin2hex($encrypted);
    }

    /**
     * @param string $code
     * @param bool $isBinary whether to decrypt as binary or not. Default is: false
     * @return string Decrypted data
     */
    function decrypt($iv_final, $key_final, $code, $isBinary = false) {
        $code = $isBinary ? $code : $this->hex2bin($code);
        $iv = $iv_final;

        $td = @mcrypt_module_open('rijndael-128', ' ', 'cbc', $iv);

        @mcrypt_generic_init($td, $key_final, $iv);
        $decrypted = @mdecrypt_generic($td, $code);

        @mcrypt_generic_deinit($td);
        @mcrypt_module_close($td);

        return $isBinary ? trim($decrypted) : utf8_encode(trim($decrypted));
    }

    protected function hex2bin($hexdata) {
        $bindata = '';

        for ($i = 0; $i < strlen($hexdata); $i += 2) {
            $bindata .= chr(hexdec(substr($hexdata, $i, 2)));
        }

        return $bindata;
    }

